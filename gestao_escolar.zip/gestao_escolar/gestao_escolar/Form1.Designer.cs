﻿namespace gestao_escolar
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTNPROFESSOR = new System.Windows.Forms.Button();
            this.BTNTURMA = new System.Windows.Forms.Button();
            this.BTNSAIR = new System.Windows.Forms.Button();
            this.BTNALUNO = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BTNPROFESSOR
            // 
            this.BTNPROFESSOR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BTNPROFESSOR.ForeColor = System.Drawing.Color.White;
            this.BTNPROFESSOR.Location = new System.Drawing.Point(102, 212);
            this.BTNPROFESSOR.Name = "BTNPROFESSOR";
            this.BTNPROFESSOR.Size = new System.Drawing.Size(96, 35);
            this.BTNPROFESSOR.TabIndex = 2;
            this.BTNPROFESSOR.Text = "PROFESSOR";
            this.BTNPROFESSOR.UseVisualStyleBackColor = false;
            this.BTNPROFESSOR.Click += new System.EventHandler(this.BTNPROFESSOR_Click);
            // 
            // BTNTURMA
            // 
            this.BTNTURMA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BTNTURMA.ForeColor = System.Drawing.Color.White;
            this.BTNTURMA.Location = new System.Drawing.Point(214, 212);
            this.BTNTURMA.Name = "BTNTURMA";
            this.BTNTURMA.Size = new System.Drawing.Size(89, 32);
            this.BTNTURMA.TabIndex = 3;
            this.BTNTURMA.Text = "TURMAS";
            this.BTNTURMA.UseVisualStyleBackColor = false;
            this.BTNTURMA.Click += new System.EventHandler(this.BTNTURMA_Click);
            // 
            // BTNSAIR
            // 
            this.BTNSAIR.BackColor = System.Drawing.Color.Maroon;
            this.BTNSAIR.ForeColor = System.Drawing.Color.White;
            this.BTNSAIR.Location = new System.Drawing.Point(319, 212);
            this.BTNSAIR.Name = "BTNSAIR";
            this.BTNSAIR.Size = new System.Drawing.Size(84, 36);
            this.BTNSAIR.TabIndex = 4;
            this.BTNSAIR.Text = "SAIR";
            this.BTNSAIR.UseVisualStyleBackColor = false;
            this.BTNSAIR.Click += new System.EventHandler(this.BTNSAIR_Click);
            // 
            // BTNALUNO
            // 
            this.BTNALUNO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BTNALUNO.ForeColor = System.Drawing.Color.White;
            this.BTNALUNO.Location = new System.Drawing.Point(12, 212);
            this.BTNALUNO.Name = "BTNALUNO";
            this.BTNALUNO.Size = new System.Drawing.Size(84, 36);
            this.BTNALUNO.TabIndex = 5;
            this.BTNALUNO.Text = "ALUNO";
            this.BTNALUNO.UseVisualStyleBackColor = false;
            this.BTNALUNO.Click += new System.EventHandler(this.BTNALUNO_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(70, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(253, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "BEM VINDO AO SISTEMA DE GESTÃO ESCOLAR";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(415, 332);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BTNALUNO);
            this.Controls.Add(this.BTNSAIR);
            this.Controls.Add(this.BTNTURMA);
            this.Controls.Add(this.BTNPROFESSOR);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNPROFESSOR;
        private System.Windows.Forms.Button BTNTURMA;
        private System.Windows.Forms.Button BTNSAIR;
        private System.Windows.Forms.Button BTNALUNO;
        private System.Windows.Forms.Label label2;
    }
}

