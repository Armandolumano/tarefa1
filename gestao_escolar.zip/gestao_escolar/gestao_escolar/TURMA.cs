﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gestao_escolar.modelos;

namespace gestao_escolar
{
    public partial class TURMA : Form
    {
        
        List<Aluno> listaTempAlunos = new List<Aluno>();

        public void AtualizarCombos()
        {
            
            CMBPROFESSOR.DataSource = null;
            CMBPROFESSOR.DataSource = Form1.listaProfessores;
            CMBPROFESSOR.DisplayMember = "nome"; 
    
            CNALUNOS.DataSource = null;
            CNALUNOS.DataSource = Form1.listaAlunos;
            CNALUNOS.DisplayMember = "nome";
        }
        private void LimparCampos()
        {
            TXTCAPACIDADE.Clear();
            TXTCODICO.Clear();
            TXTANO.Clear();
            
            
        }
        public TURMA()
        {
            InitializeComponent();
        }

        private void TURMA_Load(object sender, EventArgs e)
        {
            AtualizarCombos();
        }

        private void button3_Click(object sender, EventArgs e)
        {
     

            Turma novaTurma = new Turma(
                TXTCODICO.Text, 
                int.Parse(TXTANO.Text), 
                int.Parse(TXTCAPACIDADE.Text), 
                (Professor)CMBPROFESSOR.SelectedItem
            );

         
            foreach (var aluno in listaTempAlunos) 
            {
                novaTurma.listaAlunos.Add(aluno);
            }
                LimparCampos();



            var dadosParaExibir = new List<object>();
            dadosParaExibir.Add(new {
                Codigo = novaTurma.codigo,
                Ano = novaTurma.ano,
                Professor = novaTurma.professorResponsavel.nome,
                TotalAlunos = novaTurma.listaAlunos.Count,
                Alunos = novaTurma.listarAlunos()
            });

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = dadosParaExibir;
        }

        private void BTNADICIONAR_Click(object sender, EventArgs e)
        {

            if (CNALUNOS.SelectedItem != null)
                {
                    Aluno selecionado = (Aluno)CNALUNOS.SelectedItem;
                    listaTempAlunos.Add(selecionado);
                    MessageBox.Show("Aluno " + selecionado.nome + " preparado para a turma!");
                }
}

        private void BTNVOLTAR_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }


        }
    

