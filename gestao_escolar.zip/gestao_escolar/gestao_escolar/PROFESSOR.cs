﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gestao_escolar.modelos;

namespace gestao_escolar
{
    public partial class PROFESSOP : Form
    {
        private void LimparCampos()
        {
            TXTNOMEP.Clear();
            TXTTELEFONEP.Clear();
            TXTDATAP.Clear();
            TXTDEPARTAMENTO.Clear();
            TXTESPECIALIDADE.Clear();
            TXTSALARIO.Clear();
            TXTNOMEP.Focus();
        }
        public PROFESSOP()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void PROFESSOR_Load(object sender, EventArgs e)
        {

        }

        private void BTNVOLTARP_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTNGUARDARP_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = TXTNOMEP.Text;
                string tel = TXTTELEFONEP.Text;
                string data = TXTDATAP.Text;
                string esp = TXTESPECIALIDADE.Text;
                string dep = TXTDEPARTAMENTO.Text;
                double salario = double.Parse(TXTSALARIO.Text);

                Professor novoProf = new Professor(nome, data, tel, esp,dep,salario);

                Form1.listaProfessores.Add(novoProf);

                MessageBox.Show("Professor " + nome + " guardado com sucesso!");
                LimparCampos();
            }
            catch (Exception)
            {
                MessageBox.Show("Erro: Verifique se o salário foi digitado corretamente (Ex: 1500,50)");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
             
          
    var listaFormatada = new List<object>();

    foreach (var p in Form1.listaProfessores)
    {
        
        listaFormatada.Add(new {
            Nome = p.nome,
            DataNasc = p.dataNascimento, 
            Telefone = p.telefone,
            Departamento = p.departamento,
            Especialidade = p.especialidade,
            Salario = p.salario.ToString("N2")
        });
    }

    dataGridView1.DataSource = null;
    dataGridView1.DataSource = listaFormatada;

}

        }
    
}

