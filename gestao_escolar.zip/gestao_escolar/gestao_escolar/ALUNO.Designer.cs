﻿namespace gestao_escolar
{
    partial class ALUNO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BTNGUARDAR = new System.Windows.Forms.Button();
            this.BTNLISTA = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.TXTNOME = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TXTNUMERO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTCURSO = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTTELEFONE = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TXTDATANASCI = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TXTNOTA = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BTNADICIONARNOTA = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.lBLMEDIA = new System.Windows.Forms.Label();
            this.LBLESTADO = new System.Windows.Forms.Label();
            this.BTNCALCULAR = new System.Windows.Forms.Button();
            this.BTNVOLTAR = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BTNGUARDAR
            // 
            this.BTNGUARDAR.BackColor = System.Drawing.Color.Teal;
            this.BTNGUARDAR.ForeColor = System.Drawing.Color.White;
            this.BTNGUARDAR.Location = new System.Drawing.Point(123, 226);
            this.BTNGUARDAR.Name = "BTNGUARDAR";
            this.BTNGUARDAR.Size = new System.Drawing.Size(75, 23);
            this.BTNGUARDAR.TabIndex = 2;
            this.BTNGUARDAR.Text = "GUARDAR";
            this.BTNGUARDAR.UseVisualStyleBackColor = false;
            this.BTNGUARDAR.Click += new System.EventHandler(this.BTNGUARDAR_Click);
            // 
            // BTNLISTA
            // 
            this.BTNLISTA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.BTNLISTA.ForeColor = System.Drawing.Color.White;
            this.BTNLISTA.Location = new System.Drawing.Point(350, 226);
            this.BTNLISTA.Name = "BTNLISTA";
            this.BTNLISTA.Size = new System.Drawing.Size(75, 23);
            this.BTNLISTA.TabIndex = 13;
            this.BTNLISTA.Text = "VER LISTA";
            this.BTNLISTA.UseVisualStyleBackColor = false;
            this.BTNLISTA.Click += new System.EventHandler(this.BTNLISTA_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(360, 6);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 14;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "NOME";
            // 
            // TXTNOME
            // 
            this.TXTNOME.Location = new System.Drawing.Point(63, 19);
            this.TXTNOME.Name = "TXTNOME";
            this.TXTNOME.Size = new System.Drawing.Size(100, 20);
            this.TXTNOME.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "MECANO";
            // 
            // TXTNUMERO
            // 
            this.TXTNUMERO.Location = new System.Drawing.Point(63, 87);
            this.TXTNUMERO.Name = "TXTNUMERO";
            this.TXTNUMERO.Size = new System.Drawing.Size(100, 20);
            this.TXTNUMERO.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "CURSO";
            // 
            // TXTCURSO
            // 
            this.TXTCURSO.Location = new System.Drawing.Point(63, 45);
            this.TXTCURSO.Name = "TXTCURSO";
            this.TXTCURSO.Size = new System.Drawing.Size(100, 20);
            this.TXTCURSO.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(174, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "TELEFONE";
            // 
            // TXTTELEFONE
            // 
            this.TXTTELEFONE.Location = new System.Drawing.Point(243, 19);
            this.TXTTELEFONE.Name = "TXTTELEFONE";
            this.TXTTELEFONE.Size = new System.Drawing.Size(100, 20);
            this.TXTTELEFONE.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "DATA NASCIMENTO";
            // 
            // TXTDATANASCI
            // 
            this.TXTDATANASCI.Location = new System.Drawing.Point(292, 49);
            this.TXTDATANASCI.Name = "TXTDATANASCI";
            this.TXTDATANASCI.Size = new System.Drawing.Size(51, 20);
            this.TXTDATANASCI.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "NOTAS";
            // 
            // TXTNOTA
            // 
            this.TXTNOTA.Location = new System.Drawing.Point(57, 130);
            this.TXTNOTA.Name = "TXTNOTA";
            this.TXTNOTA.Size = new System.Drawing.Size(100, 20);
            this.TXTNOTA.TabIndex = 12;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.BTNADICIONARNOTA);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Controls.Add(this.TXTNOTA);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.TXTDATANASCI);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.TXTTELEFONE);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.TXTCURSO);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.TXTNUMERO);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.TXTNOME);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(-3, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(357, 203);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // BTNADICIONARNOTA
            // 
            this.BTNADICIONARNOTA.BackColor = System.Drawing.Color.Teal;
            this.BTNADICIONARNOTA.ForeColor = System.Drawing.Color.White;
            this.BTNADICIONARNOTA.Location = new System.Drawing.Point(63, 164);
            this.BTNADICIONARNOTA.Name = "BTNADICIONARNOTA";
            this.BTNADICIONARNOTA.Size = new System.Drawing.Size(82, 23);
            this.BTNADICIONARNOTA.TabIndex = 14;
            this.BTNADICIONARNOTA.Text = "ADICIONAR ";
            this.BTNADICIONARNOTA.UseVisualStyleBackColor = false;
            this.BTNADICIONARNOTA.Click += new System.EventHandler(this.BTNADICIONARNOTA_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(165, 133);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(119, 56);
            this.listBox1.TabIndex = 13;
            // 
            // lBLMEDIA
            // 
            this.lBLMEDIA.AutoSize = true;
            this.lBLMEDIA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.lBLMEDIA.ForeColor = System.Drawing.Color.White;
            this.lBLMEDIA.Location = new System.Drawing.Point(498, 170);
            this.lBLMEDIA.Name = "lBLMEDIA";
            this.lBLMEDIA.Size = new System.Drawing.Size(41, 13);
            this.lBLMEDIA.TabIndex = 18;
            this.lBLMEDIA.Text = "MEDIA";
            this.lBLMEDIA.Click += new System.EventHandler(this.lBLMEDIA_Click);
            // 
            // LBLESTADO
            // 
            this.LBLESTADO.AutoSize = true;
            this.LBLESTADO.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.LBLESTADO.ForeColor = System.Drawing.Color.White;
            this.LBLESTADO.Location = new System.Drawing.Point(360, 170);
            this.LBLESTADO.Name = "LBLESTADO";
            this.LBLESTADO.Size = new System.Drawing.Size(51, 13);
            this.LBLESTADO.TabIndex = 19;
            this.LBLESTADO.Text = "ESTADO";
            // 
            // BTNCALCULAR
            // 
            this.BTNCALCULAR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BTNCALCULAR.ForeColor = System.Drawing.Color.White;
            this.BTNCALCULAR.Location = new System.Drawing.Point(240, 226);
            this.BTNCALCULAR.Name = "BTNCALCULAR";
            this.BTNCALCULAR.Size = new System.Drawing.Size(75, 23);
            this.BTNCALCULAR.TabIndex = 20;
            this.BTNCALCULAR.Text = "CALCULAR";
            this.BTNCALCULAR.UseVisualStyleBackColor = false;
            this.BTNCALCULAR.Click += new System.EventHandler(this.BTNCALCULAR_Click);
            // 
            // BTNVOLTAR
            // 
            this.BTNVOLTAR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BTNVOLTAR.ForeColor = System.Drawing.Color.White;
            this.BTNVOLTAR.Location = new System.Drawing.Point(12, 227);
            this.BTNVOLTAR.Name = "BTNVOLTAR";
            this.BTNVOLTAR.Size = new System.Drawing.Size(75, 23);
            this.BTNVOLTAR.TabIndex = 21;
            this.BTNVOLTAR.Text = "VOLTAR";
            this.BTNVOLTAR.UseVisualStyleBackColor = false;
            this.BTNVOLTAR.Click += new System.EventHandler(this.BTNVOLTAR_Click);
            // 
            // ALUNO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 407);
            this.Controls.Add(this.BTNVOLTAR);
            this.Controls.Add(this.BTNCALCULAR);
            this.Controls.Add(this.LBLESTADO);
            this.Controls.Add(this.lBLMEDIA);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.BTNLISTA);
            this.Controls.Add(this.BTNGUARDAR);
            this.Name = "ALUNO";
            this.Text = "ALUNO";
            this.Load += new System.EventHandler(this.ALUNO_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BTNGUARDAR;
        private System.Windows.Forms.Button BTNLISTA;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TXTNOME;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TXTNUMERO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTCURSO;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXTTELEFONE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TXTDATANASCI;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TXTNOTA;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lBLMEDIA;
        private System.Windows.Forms.Label LBLESTADO;
        private System.Windows.Forms.Button BTNADICIONARNOTA;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button BTNCALCULAR;
        private System.Windows.Forms.Button BTNVOLTAR;
    }
}