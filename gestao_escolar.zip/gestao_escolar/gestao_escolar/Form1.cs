﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using gestao_escolar.modelos;

namespace gestao_escolar
{
    public partial class Form1 : Form
    {
   
        public static List<Aluno> listaAlunos = new List<Aluno>();
        public static List<Professor> listaProfessores = new List<Professor>();
        public static List<Turma> listaTurmas = new List<Turma>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void BTNSAIR_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void BTNTURMA_Click(object sender, EventArgs e)
        {

            TURMA frmTurma = new TURMA();
            frmTurma.ShowDialog();
        }

        private void BTNPROFESSOR_Click(object sender, EventArgs e)
        {

            PROFESSOP frmProf = new PROFESSOP();
            frmProf.ShowDialog();
        }

        private void BTNALUNO_Click(object sender, EventArgs e)
        {
            ALUNO frmAluno = new ALUNO();
            frmAluno.ShowDialog(); 

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
 
 