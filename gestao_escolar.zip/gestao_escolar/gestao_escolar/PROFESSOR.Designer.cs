﻿namespace gestao_escolar
{
    partial class PROFESSOP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXTESPECIALIDADE = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TXTDATAP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.TXTTELEFONEP = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTDEPARTAMENTO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTNOMEP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BTNVERLISTA = new System.Windows.Forms.Button();
            this.BTNGUARDARP = new System.Windows.Forms.Button();
            this.TXTSALARIO = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BTNVOLTARP = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // TXTESPECIALIDADE
            // 
            this.TXTESPECIALIDADE.Location = new System.Drawing.Point(141, 72);
            this.TXTESPECIALIDADE.Name = "TXTESPECIALIDADE";
            this.TXTESPECIALIDADE.Size = new System.Drawing.Size(100, 20);
            this.TXTESPECIALIDADE.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(138, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "ESPECIALIDADE";
            // 
            // TXTDATAP
            // 
            this.TXTDATAP.Location = new System.Drawing.Point(141, 27);
            this.TXTDATAP.Name = "TXTDATAP";
            this.TXTDATAP.Size = new System.Drawing.Size(100, 20);
            this.TXTDATAP.TabIndex = 22;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(138, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 21;
            this.label5.Text = "DATA NASCIMENTO";
            // 
            // TXTTELEFONEP
            // 
            this.TXTTELEFONEP.Location = new System.Drawing.Point(266, 27);
            this.TXTTELEFONEP.Name = "TXTTELEFONEP";
            this.TXTTELEFONEP.Size = new System.Drawing.Size(100, 20);
            this.TXTTELEFONEP.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(268, 11);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "TELEFONE";
            // 
            // TXTDEPARTAMENTO
            // 
            this.TXTDEPARTAMENTO.Location = new System.Drawing.Point(10, 74);
            this.TXTDEPARTAMENTO.Name = "TXTDEPARTAMENTO";
            this.TXTDEPARTAMENTO.Size = new System.Drawing.Size(100, 20);
            this.TXTDEPARTAMENTO.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "DEPARTAMENTO";
            // 
            // TXTNOMEP
            // 
            this.TXTNOMEP.Location = new System.Drawing.Point(10, 27);
            this.TXTNOMEP.Name = "TXTNOMEP";
            this.TXTNOMEP.Size = new System.Drawing.Size(100, 20);
            this.TXTNOMEP.TabIndex = 14;
            this.TXTNOMEP.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "NOME";
            // 
            // BTNVERLISTA
            // 
            this.BTNVERLISTA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.BTNVERLISTA.ForeColor = System.Drawing.Color.White;
            this.BTNVERLISTA.Location = new System.Drawing.Point(232, 308);
            this.BTNVERLISTA.Name = "BTNVERLISTA";
            this.BTNVERLISTA.Size = new System.Drawing.Size(75, 23);
            this.BTNVERLISTA.TabIndex = 26;
            this.BTNVERLISTA.Text = "VER LISTA";
            this.BTNVERLISTA.UseVisualStyleBackColor = false;
            this.BTNVERLISTA.Click += new System.EventHandler(this.button2_Click);
            // 
            // BTNGUARDARP
            // 
            this.BTNGUARDARP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BTNGUARDARP.ForeColor = System.Drawing.Color.White;
            this.BTNGUARDARP.Location = new System.Drawing.Point(132, 308);
            this.BTNGUARDARP.Name = "BTNGUARDARP";
            this.BTNGUARDARP.Size = new System.Drawing.Size(75, 23);
            this.BTNGUARDARP.TabIndex = 25;
            this.BTNGUARDARP.Text = "GUARDAR";
            this.BTNGUARDARP.UseVisualStyleBackColor = false;
            this.BTNGUARDARP.Click += new System.EventHandler(this.BTNGUARDARP_Click);
            // 
            // TXTSALARIO
            // 
            this.TXTSALARIO.Location = new System.Drawing.Point(266, 70);
            this.TXTSALARIO.Name = "TXTSALARIO";
            this.TXTSALARIO.Size = new System.Drawing.Size(100, 20);
            this.TXTSALARIO.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(268, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "SALARIO";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 100);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(582, 202);
            this.dataGridView1.TabIndex = 29;
            // 
            // BTNVOLTARP
            // 
            this.BTNVOLTARP.BackColor = System.Drawing.Color.Maroon;
            this.BTNVOLTARP.ForeColor = System.Drawing.Color.White;
            this.BTNVOLTARP.Location = new System.Drawing.Point(26, 308);
            this.BTNVOLTARP.Name = "BTNVOLTARP";
            this.BTNVOLTARP.Size = new System.Drawing.Size(75, 23);
            this.BTNVOLTARP.TabIndex = 30;
            this.BTNVOLTARP.Text = "VOLTAR";
            this.BTNVOLTARP.UseVisualStyleBackColor = false;
            this.BTNVOLTARP.Click += new System.EventHandler(this.BTNVOLTARP_Click);
            // 
            // PROFESSOP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(606, 343);
            this.Controls.Add(this.BTNVOLTARP);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.TXTSALARIO);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.BTNVERLISTA);
            this.Controls.Add(this.BTNGUARDARP);
            this.Controls.Add(this.TXTESPECIALIDADE);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TXTDATAP);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TXTTELEFONEP);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TXTDEPARTAMENTO);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TXTNOMEP);
            this.Controls.Add(this.label1);
            this.Name = "PROFESSOP";
            this.Text = "PROFESSOR";
            this.Load += new System.EventHandler(this.PROFESSOR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXTESPECIALIDADE;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TXTDATAP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TXTTELEFONEP;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXTDEPARTAMENTO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTNOMEP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTNVERLISTA;
        private System.Windows.Forms.Button BTNGUARDARP;
        private System.Windows.Forms.TextBox TXTSALARIO;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button BTNVOLTARP;
    }
}