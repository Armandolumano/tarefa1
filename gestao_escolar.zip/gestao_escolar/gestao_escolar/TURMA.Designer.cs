﻿namespace gestao_escolar
{
    partial class TURMA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TXTCAPACIDADE = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTCODICO = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTANO = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.BTNADICIONAR = new System.Windows.Forms.Button();
            this.BTNVOLTAR = new System.Windows.Forms.Button();
            this.BTNCRIAR = new System.Windows.Forms.Button();
            this.CMBPROFESSOR = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CNALUNOS = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // TXTCAPACIDADE
            // 
            this.TXTCAPACIDADE.Location = new System.Drawing.Point(292, 6);
            this.TXTCAPACIDADE.Name = "TXTCAPACIDADE";
            this.TXTCAPACIDADE.Size = new System.Drawing.Size(100, 20);
            this.TXTCAPACIDADE.TabIndex = 20;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(201, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 19;
            this.label6.Text = "CAPACIDADE";
            // 
            // TXTCODICO
            // 
            this.TXTCODICO.Location = new System.Drawing.Point(64, 6);
            this.TXTCODICO.Name = "TXTCODICO";
            this.TXTCODICO.Size = new System.Drawing.Size(100, 20);
            this.TXTCODICO.TabIndex = 18;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "CODICO";
            // 
            // TXTANO
            // 
            this.TXTANO.Location = new System.Drawing.Point(64, 41);
            this.TXTANO.Name = "TXTANO";
            this.TXTANO.Size = new System.Drawing.Size(75, 20);
            this.TXTANO.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "ANO";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(398, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(340, 147);
            this.dataGridView1.TabIndex = 21;
            // 
            // BTNADICIONAR
            // 
            this.BTNADICIONAR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.BTNADICIONAR.ForeColor = System.Drawing.Color.White;
            this.BTNADICIONAR.Location = new System.Drawing.Point(141, 132);
            this.BTNADICIONAR.Name = "BTNADICIONAR";
            this.BTNADICIONAR.Size = new System.Drawing.Size(75, 23);
            this.BTNADICIONAR.TabIndex = 22;
            this.BTNADICIONAR.Text = "ADICIONAR ";
            this.BTNADICIONAR.UseVisualStyleBackColor = false;
            this.BTNADICIONAR.Click += new System.EventHandler(this.BTNADICIONAR_Click);
            // 
            // BTNVOLTAR
            // 
            this.BTNVOLTAR.BackColor = System.Drawing.Color.Maroon;
            this.BTNVOLTAR.ForeColor = System.Drawing.Color.White;
            this.BTNVOLTAR.Location = new System.Drawing.Point(24, 229);
            this.BTNVOLTAR.Name = "BTNVOLTAR";
            this.BTNVOLTAR.Size = new System.Drawing.Size(75, 23);
            this.BTNVOLTAR.TabIndex = 28;
            this.BTNVOLTAR.Text = "VOLTAR";
            this.BTNVOLTAR.UseVisualStyleBackColor = false;
            this.BTNVOLTAR.Click += new System.EventHandler(this.BTNVOLTAR_Click);
            // 
            // BTNCRIAR
            // 
            this.BTNCRIAR.BackColor = System.Drawing.Color.Navy;
            this.BTNCRIAR.ForeColor = System.Drawing.Color.White;
            this.BTNCRIAR.Location = new System.Drawing.Point(139, 229);
            this.BTNCRIAR.Name = "BTNCRIAR";
            this.BTNCRIAR.Size = new System.Drawing.Size(126, 23);
            this.BTNCRIAR.TabIndex = 29;
            this.BTNCRIAR.Text = "CRIAR TURMA";
            this.BTNCRIAR.UseVisualStyleBackColor = false;
            this.BTNCRIAR.Click += new System.EventHandler(this.button3_Click);
            // 
            // CMBPROFESSOR
            // 
            this.CMBPROFESSOR.FormattingEnabled = true;
            this.CMBPROFESSOR.Location = new System.Drawing.Point(271, 45);
            this.CMBPROFESSOR.Name = "CMBPROFESSOR";
            this.CMBPROFESSOR.Size = new System.Drawing.Size(121, 21);
            this.CMBPROFESSOR.TabIndex = 30;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(178, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(87, 13);
            this.label1.TabIndex = 31;
            this.label1.Text = "PROFESSORES";
            // 
            // CNALUNOS
            // 
            this.CNALUNOS.FormattingEnabled = true;
            this.CNALUNOS.Location = new System.Drawing.Point(128, 105);
            this.CNALUNOS.Name = "CNALUNOS";
            this.CNALUNOS.Size = new System.Drawing.Size(99, 21);
            this.CNALUNOS.TabIndex = 32;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "LISTAR ALUNOS";
            // 
            // TURMA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 269);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.CNALUNOS);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CMBPROFESSOR);
            this.Controls.Add(this.BTNCRIAR);
            this.Controls.Add(this.BTNVOLTAR);
            this.Controls.Add(this.BTNADICIONAR);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.TXTCAPACIDADE);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.TXTCODICO);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TXTANO);
            this.Controls.Add(this.label2);
            this.Name = "TURMA";
            this.Text = "TURMA";
            this.Load += new System.EventHandler(this.TURMA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXTCAPACIDADE;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXTCODICO;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTANO;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button BTNADICIONAR;
        private System.Windows.Forms.Button BTNVOLTAR;
        private System.Windows.Forms.Button BTNCRIAR;
        private System.Windows.Forms.ComboBox CMBPROFESSOR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox CNALUNOS;
        private System.Windows.Forms.Label label4;
    }
}